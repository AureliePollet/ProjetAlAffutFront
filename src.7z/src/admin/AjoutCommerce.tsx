import '../styles/style.css';
import '../styles/bootstrap.css';
import NavAdmin from '../components/NavAdmin';
import FormAjouterCommerce from '../components/FormAjouterCom';



function AjoutCommerce() {
    return (
        <main id="AjoutCommerce"> 
        <NavAdmin/>
        <FormAjouterCommerce/>
        
    </main>
    )
}
export default AjoutCommerce;