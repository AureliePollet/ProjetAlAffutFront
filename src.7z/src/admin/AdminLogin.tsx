import '../styles/style.css';
import '../styles/bootstrap.css';
import NavAdmin from '../components/NavAdmin';



function AdminLogin() {
    return (
        <main id="AdminLogin">
        <NavAdmin/>
         <h1>Bienvenue sur la page administrateur</h1> 
         
    </main>
    )
}

export default AdminLogin;